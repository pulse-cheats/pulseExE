# Pulse Executor macOS Dylib (High UNC & Sync)

This repository contains the GitHub Actions workflow and C++ source code to automatically compile a macOS `.dylib` dynamic library for Pulse Executor featuring **High UNC (Unified Naming Convention)** and robust **Synchronous/Asynchronous execution**.

## Features Included:
- **High UNC Compatibility**: Stubs & environment tables for `getgenv`, `getrenv`, `getreg`, `getgc`, `fireclickdetector`, `newcclosure`, `checkcaller`, `identifyexecutor`.
- **Sync & Async Execution**: Supports synchronous script evaluation (`loadstring`) and asynchronous task threads.
- **Automated GitHub Actions**: Compiles instantly via `macos-latest`.

## How to Build:
1. Push to GitHub.
2. Go to **Actions** -> **Build Pulse Dylib**.
3. Download `PulseExecutor.dylib`.
